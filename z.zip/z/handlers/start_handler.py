import os

from aiogram import Router
from aiogram.types import Message

from database import dbworker

from keyboards.admin_kb import admin_kb
from keyboards.user_kb import start_user_kb
from aiogram.filters import CommandStart

start_router = Router()


@start_router.message(CommandStart())
async def send_welcome(message: Message):
    db = dbworker(os.getenv('DATABASE_NAME'))
    admin_id = os.getenv('ADMIN_ID')
    if str(message.from_user.id) in str(admin_id):
        await message.answer('Вы авторизовались как админ', reply_markup=admin_kb())
    else:
        if not db.user_exists(message.from_user.id):
            db.add_user(message.from_user.username, message.from_user.id)
        price = db.select_price()

        await message.answer(f"Приветствую!\nЭто бот по продаже своих NOT коинов.\n"
                             f"Для начала советую ознакомиться с правилами по кнопке 'Правила'\n"
                             f"После ознакомления нажимай на кнопку 'Продать NOT' и оставляй свою заявку прямо сейчас.\n\n"
                             f"Актуальный курс на данный момент: 1 монета = {price[0]} рублей ", reply_markup=start_user_kb())



