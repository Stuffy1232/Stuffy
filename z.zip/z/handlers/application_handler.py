import os
from aiogram import Bot, Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from states.application_state import ApplicationState
from keyboards.admin_kb import result_kb

user_application_router = Router()


# __________________________Вопросы__________________________
question_1 = "Какое кол-во ноткоинов?"
question_2 = "Выведены ли они уже на кошелек?"
question_3 = "Есть ли у Вас TON для оплаты комиссии?"


@user_application_router.message(F.text == 'Продать NOT')
async def apl_state1(message: Message, state: FSMContext):
    await message.answer(question_1)
    await state.set_state(ApplicationState.question1)

@user_application_router.message(ApplicationState.question1)
async def apl_state2(message: Message, bot: Bot, state: FSMContext):
    if message.text.isdigit():
        await state.update_data(question1=message.text)
        await bot.send_message(message.from_user.id, question_2)
        await state.set_state(ApplicationState.question2)
    else:
        await message.answer('Вы можете написать только количество коинов')

@user_application_router.message(ApplicationState.question2)
async def apl_state3(message: Message, bot: Bot, state: FSMContext):
    if message.text.lower() == 'да' or message.text.lower() == 'нет':
        await state.update_data(question2=message.text)
        await bot.send_message(message.from_user.id, question_3)
        await state.set_state(ApplicationState.question3)
    else:
        await message.answer('Вы можете ответить Да/Нет')


@user_application_router.message(ApplicationState.question3)
async def apl_state_finish(message: Message, bot: Bot, state: FSMContext):
    if message.text.lower() == 'да' or message.text.lower() == 'нет':
        await state.update_data(question3=message.text)
        data = await state.get_data()
        await bot.send_message(message.from_user.id, f'Ваша заявка отправлена админу на рассмотрение\n\n'
                                                     f'{question_1}: {data["question1"]}\n'
                                                     f'{question_2}: {data["question2"]}\n'
                                                     f'{question_3}: {data["question3"]}\n')
        admin_id = os.getenv('ADMIN_ID')
        await bot.send_message(admin_id, f'Поступила заявка от: {message.from_user.username}\n'
                                         f'ID: {message.from_user.id}\n\n'
                                         f'{question_1}: {data["question1"]}\n'
                                         f'{question_2}: {data["question2"]}\n'
                                         f'{question_3}: {data["question3"]}\n', reply_markup=result_kb(message.from_user.id))
        await state.clear()
    else:
        await message.answer('Вы можете ответить Да/Нет')
