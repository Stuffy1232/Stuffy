import os
from aiogram import Bot, Router, F
from aiogram.types import CallbackQuery, Message
from database import dbworker
from aiogram.fsm.context import FSMContext
from filters.filters_and_midl import CheckAdmin
from states.application_state import PriceState

admin_router = Router()
admin_router.message.filter(CheckAdmin())


@admin_router.message(F.text == 'Сменить курс')
async def change_price(message: Message, bot: Bot, state: FSMContext):
    await message.answer(f'Введите новый курс: 1 монета == ... рубелй')
    await state.set_state(PriceState.price)


@admin_router.message(PriceState.price)
async def change_state(message: Message, bot: Bot, state: FSMContext):
    await state.update_data(price=message.text)
    data = await state.get_data()
    db = dbworker(os.getenv('DATABASE_NAME'))
    db.change_price(data["price"])
    await message.answer(f'Курс изменен!\n\n'
                         f'Актуальный курс на данный момент: 1 монета = {data["price"]} рублей')
    await state.clear()


@admin_router.callback_query(F.data.startswith('accept_'))
async def accept_res(callback: CallbackQuery, bot: Bot):
    await callback.answer()
    telegram_id = callback.data.split('_')[1]
    admin_username = os.getenv('ADMIN_USERNAME')
    await callback.message.answer(f'✅ Заявка пользователя {telegram_id} одобрена!')
    await bot.send_message(telegram_id, f'✅ Ваша заявка одобрена, напишите сюда: {admin_username}')

@admin_router.callback_query(F.data.startswith('close_'))
async def close_res(callback: CallbackQuery, bot: Bot):
    await callback.answer()
    telegram_id = callback.data.split('_')[1]
    await callback.message.answer(f'❌ Заявка пользователя {telegram_id} отклонена')
    await bot.send_message(telegram_id, f'❌ Ваша заявка была отклонена администрацией.')