import logging
import os
from aiogram import Bot, Dispatcher
import asyncio
from dotenv import load_dotenv

from handlers.admin_handler import admin_router
from handlers.start_handler import start_router
from handlers.application_handler import user_application_router

load_dotenv()

token = os.getenv('BOT_TOKEN')

logging.basicConfig(level=logging.INFO)
bot = Bot(token=token)
dp = Dispatcher()

dp.include_router(start_router)
dp.include_router(admin_router)
dp.include_router(user_application_router)


async def main():
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.run(main())
