import sqlite3

class dbworker:
    def __init__(self, database_file):
        self.connection = sqlite3.connect(database_file)
        self.cursor = self.connection.cursor()

    def user_exists(self, user_id):
        with self.connection:
            result = self.cursor.execute('SELECT telegram_id FROM `users` WHERE `telegram_id` = ?', (user_id,)).fetchall()
            return bool(len(result))

    def select_user(self, user_telegram_id):
        users = self.cursor.execute('SELECT * FROM users WHERE telegram_id = ?', (user_telegram_id,))
        return users.fetchone()

    def add_user(self,telegram_username, telegram_id):
    	with self.connection:
    		return self.cursor.execute("INSERT INTO `users` (`telegram_username`, `telegram_id`) VALUES(?,?)", (telegram_username, telegram_id,))


    def change_price(self, price):
        with self.connection:
            self.cursor.execute('UPDATE settings SET price = ?', (price,))
            self.connection.commit()

    def select_price(self):
        with self.connection:
            result = self.cursor.execute('SELECT price FROM settings')
            return result.fetchone()
