from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder



def start_user_kb():
    kb = ReplyKeyboardBuilder()
    kb.button(text='Продать NOT')
    kb.button(text='Правила')
    kb.adjust(1)
    return kb.as_markup(resize_keyboard=True)

