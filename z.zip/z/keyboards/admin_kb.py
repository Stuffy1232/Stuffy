from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder


def result_kb(ids):
    ikb1 = InlineKeyboardBuilder()
    ikb1.button(text='✅ Принять', callback_data=f'accept_{ids}')
    ikb1.button(text='❌ Отклонить', callback_data=f'close_{ids}')
    ikb1.adjust(1)
    return ikb1.as_markup()


def admin_kb():
    kb = ReplyKeyboardBuilder()
    kb.button(text='Сменить курс')
    kb.adjust(2)
    return kb.as_markup(resize_keyboard=True, one_time_keyboard=True)

