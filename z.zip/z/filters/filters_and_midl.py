import os
from aiogram.filters import BaseFilter
from aiogram.types import Message


class CheckAdmin(BaseFilter):
    async def __call__(self, message: Message):
        try:
            admin_id = os.getenv('ADMIN_ID')
            return str(message.from_user.id) == str(admin_id)
        except:
            return False

