from aiogram.fsm.state import State, StatesGroup


class ApplicationState(StatesGroup):
    question1 = State()
    question2 = State()
    question3 = State()



class PriceState(StatesGroup):
    price = State()
